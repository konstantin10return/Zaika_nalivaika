# drinks = ('Газированная вода', 'Мятный сироп', 'Апельсиновый сок', 'Лимонад “Мятный”', 'Лимонад “Заводной апельсин”')
drinks_and_message_coeds = {'Газированная вода': '1', 'Мятный сироп': '2', 'Апельсиновый сок': '3',
                            'Лимонад “Мятный”': '4', 'Лимонад “Заводной апельсин”': '5', 'Лимонад ‘Тройной”': '6'}
drinks = list(drinks_and_message_coeds.keys())
max_glases_count = 4
empty_glass_value = 0
order_prefix = 'order:'

RESIZE_INTERFEISE = False